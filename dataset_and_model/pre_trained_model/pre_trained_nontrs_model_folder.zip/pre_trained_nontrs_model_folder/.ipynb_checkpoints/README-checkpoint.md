# AutoML Leaderboard

| Best model   | name                                             | model_type   | metric_type   |   metric_value |   train_time |
|:-------------|:-------------------------------------------------|:-------------|:--------------|---------------:|-------------:|
| **the best** | [1_Default_Xgboost](1_Default_Xgboost/README.md) | Xgboost      | logloss       |       0.455853 |        42.03 |